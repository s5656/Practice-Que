package com.testvagrant.cricket;

import java.util.Arrays;

public class TeamDetails {
	
	private String nameOfTeam;
	private int points;
	private char[] result;
	
	TeamDetails(){}
	
	public TeamDetails(String nameOfTeam, int points, char[] result) {
		super();
		this.nameOfTeam = nameOfTeam;
		this.points = points;
		this.result = result;
	}
	
	
	public String getNameOfTeam() {
		return nameOfTeam;
	}
	public void setNameOfTeam(String nameOfTeam) {
		this.nameOfTeam = nameOfTeam;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public char[] getResult() {
		return result;
	}
	public void setResult(char[] result) {
		this.result = result;
	}

	public String toString() {
		return "TeamDetails [nameOfTeam=" + nameOfTeam + ", points=" + points + ", result=" + Arrays.toString(result)
				+ "]";
	}

}
