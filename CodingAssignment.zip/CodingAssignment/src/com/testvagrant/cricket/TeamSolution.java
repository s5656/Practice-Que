package com.testvagrant.cricket;

import java.util.ArrayList;
import java.util.Scanner;

public class TeamSolution {

	public static void main(String[] args) {
		
		try {
			
			ArrayList<TeamDetails> team = new ArrayList();

			team.add(new TeamDetails("GT", 20, new char[] { 'W', 'W', 'L', 'L', 'W' }));
			team.add(new TeamDetails("LSG", 18, new char[] { 'W', 'L', 'L', 'W', 'W' }));
			team.add(new TeamDetails("RR", 16, new char[] { 'W', 'L', 'W', 'L', 'L' }));
			team.add(new TeamDetails("DC", 14, new char[] { 'W', 'W', 'L', 'W', 'L' }));
			team.add(new TeamDetails("RCB", 14, new char[] { 'L', 'W', 'W', 'L', 'L' }));
			team.add(new TeamDetails("KKR", 12, new char[] { 'L', 'W', 'W', 'L', 'W' }));
			team.add(new TeamDetails("PBKS", 12, new char[] { 'L', 'W', 'L', 'W', 'L' }));
			team.add(new TeamDetails("SRH", 12, new char[] { 'W', 'L', 'L', 'L', 'L' }));
			team.add(new TeamDetails("CSK", 6, new char[] { 'L', 'L', 'W', 'L', 'W' }));
			team.add(new TeamDetails("SRH", 6, new char[] { 'L', 'W', 'L', 'W', 'W' }));
			
			ArrayList<TeamDetails> ar = new ArrayList<>();
			ArrayList<TeamDetails> loss = new ArrayList<>();
			
			for (TeamDetails teamDetails : team) {
				
				char [] result = teamDetails.getResult();
			
				String str ="";
			
				for (int i = 0; i < result.length; i++) {	
					str = str+result[i];
				}
				
				if (winLoss(str.toUpperCase(), 'L', 2) == 1) {
					loss.add(teamDetails);
				}
			}
			
			System.out.println("The teams who was having two consecutive Losses are");
			System.out.println(loss);
			System.out.println("=========================================");
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter what you want to find W OR L");
			char ip = sc.next().toUpperCase().charAt(0);
			System.out.println("Enter how many consecutive wins or loss you want to find out");
			int ip2 = sc.nextInt();
			
				for (TeamDetails teamDetails : team) {
					
					char [] result = teamDetails.getResult();
				
					String str ="";
				
					for (int i = 0; i < result.length; i++) {	
						str = str+result[i];
					}
				
				if (winLoss(str.toUpperCase(), ip, ip2) == 1) {	
					ar.add(teamDetails);
				}
				
			}
			int sum = 0;
			double avg=0;
			for (int i = 0; i < ar.size(); i++) {
				sum = sum+ar.get(i).getPoints();		
			}

			System.out.println("The teams having n consecutive Loasses/Wins are");
			System.out.println(ar);
			System.out.println("============================================");
			System.out.println("The average of teams is :"+ sum/ar.size());	
			
		} catch (ArithmeticException e) {
			
			System.out.println("There is no such team");
			System.out.println("Please enter valid response...!!");
			
		}catch (Exception e) {
			
			System.out.println("Please enter valid response....!!");
		}
	}
	public static int winLoss(String s1,char ip,int ip2)
	{
		int count=0;
		String con ="";
		
		for (int i = 0; i < ip2; i++) {
			con = con+ip;
		}
	
		if (s1.contains(con)) {
				
			count++;
				
			}
		return count;
	}
}

